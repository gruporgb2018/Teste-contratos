import React, { useState } from "react";

export default function App() {
  const [form, setForm] = useState({
    nome: "",
    cpf: "",
    telefone: "",
    endereco: "",
    dataEvento: "",
    duracao: "",
    horario: "",
    valorTotal: "",
    valorEntrada: "",
  });

  const [preview, setPreview] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const gerarContrato = () => {
    const contrato = `CONTRATO DE PRESTAÇÃO DE SERVIÇOS

Eu, ${form.nome}, CPF ${form.cpf}, residente em ${form.endereco}, contrato o serviço para o evento na data ${form.dataEvento}, com duração de ${form.duracao} horas, previsto para iniciar às ${form.horario}.

Valor total: R$ ${form.valorTotal}. Entrada: R$ ${form.valorEntrada}.

Telefone para contato: ${form.telefone}.`;
    setPreview(contrato);
  };

  return (
    <div>
      <h1>Gerar Contrato</h1>
      {Object.keys(form).map((campo) => (
        <input
          key={campo}
          name={campo}
          value={form[campo]}
          placeholder={campo}
          onChange={handleChange}
        />
      ))}
      <button onClick={gerarContrato}>Gerar</button>
      <pre>{preview}</pre>
    </div>
  );
}
